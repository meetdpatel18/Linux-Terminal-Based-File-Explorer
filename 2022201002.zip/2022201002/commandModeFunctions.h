//-----TRIM EXTRA SPACES-----------
string trim_extra_spaces(string ip){
    string res="";
    int n=ip.size();

    for(int i=0; i<n; i++){
        if(ip[i]==' ' && res=="") continue;
        else if(ip[i]==' ' && res[res.size()-1]==' ') continue;
        else if(ip[i]== ' ' && res[res.size()-1]!=' '){
            res=res+" ";
        }
        else{
            res=res+ip[i];
        }
    }
    return res;
}


//----------------------------------
//---------SEARCH FILE--------------
//--------OR DIRECTORY--------------
//----------------------------------
bool searchFileDir(string path, string fileToSearch)
{
    DIR *dir;
    struct dirent *x;
    string s;
    bool isD;

    if ((dir = opendir(path.c_str())) != NULL)
    {
        while ((x = readdir(dir)) != NULL)
        {
            s = x->d_name;
            if (s == "." || s == "..")
                continue;

            isD = isDir(path);

            if (fileToSearch == s)
            {
                return true;
            }
            else
            {
                if (isD)
                {
                    if (searchFileDir(path + "/" + s, fileToSearch))
                        return true;
                }
            }
        }
        closedir(dir);
    }
    return false;
}

//----------------------------------
//---------DELETE CHECKER-----------
//-----------FUNCTION---------------
//----------------------------------
bool canDelete(string src)
{
    if(src=="/") {
        cout << endl
             << "Cannot Delete Directory go to same level as that of directory that you want to delete" << endl;
        return false;
    }
    int ind = currPath.find(src + "/");

    if ((ind != string::npos && ind == 0) || src == currPath)
    {
        cout << endl
             << "Cannot Delete Directory go to same level as that of directory that you want to delete" << endl;
        return false;
    }
    return true;
}

//----------------------------------
//---------COPY CHECKER-----------
//-----------FUNCTION---------------
//----------------------------------
bool canCopy(string src, string dest)
{
    if(src=="/") {
        cout << endl
             << "Cannot Copy Parent Directory to Child Directory" << endl;
        return false;
    }
    if(src==dest){
        cout << endl
             << "Cannot Copy Same Directory To Itself" << endl;
        return false;
    }
    int ind = dest.find(src + "/");

    if (ind != string::npos && ind == 0)
    {
        cout << endl
             << "Cannot Copy Parent Directory to Child Directory" << endl;
        return false;
    }
    return true;
}

//----------------------------------
//-------------MOVE-----------------
//-----------FUNCTION---------------
//----------------------------------
void move(vector<string> path)
{
    int n = path.size();
    string dest = path[n - 1];
    dest = parsePath(dest);

     DIR *dir = opendir(dest.c_str());
    if(dir==NULL){
        cerr<<endl<<"Invalid Path : Error: "<<strerror(errno);
        return;
    }

    int fd = access(dest.c_str(), (W_OK));
    if(fd == -1){
        cout<<endl;
        perror("Error Description:");
        cout<<endl;
        return;
    }

    for (int i = 1; i < n - 1; i++)
    {
        string src = path[i];
        src = parsePath(src);

        struct stat ip;
        if (stat((src).c_str(), &ip) != 0)
        {
            cout << endl
                 << "Unable to find information for specified path" << endl;
            continue;
        }

        if (S_ISDIR(ip.st_mode))
        {
            if (findParent(src) == dest)
            {
                cout << endl
                     << "Directory already exist in the destination" << endl;
                return;
            }

            if (canCopy(src, dest) && canDelete(src))
            {
                copyDirectory(src, dest);
                delete_entire_dir(src);
            }
        }
        else
        {
            if (findParent(src) == dest)
            {
                cout << endl
                     << "File already exist in the destination" << endl;
                return;
            }
            copyFile(src, dest);
            delete_file(src);
        }
    }
}

//----------------------------------
//-------------COPY-----------------
//-----------FUNCTION---------------
//----------------------------------
void copy(vector<string> path)
{
    int n = path.size();
    string dest = path[n - 1];
    dest = parsePath(dest);

    DIR *dir = opendir(dest.c_str());
    if(dir==NULL){
        cerr<<endl<<"Invalid Path : Error: "<<strerror(errno);
        return;
    }

    int fd = access(dest.c_str(), (W_OK));
    if(fd == -1){
        cout<<endl;
        perror("Error Description:");
        cout<<endl;
        return;
    }

    for (int i = 1; i < n - 1; i++)
    {
        string src = path[i];
        src = parsePath(src);

        struct stat ip;
        if (stat((src).c_str(), &ip) != 0)
        {
            cout << endl
                 << "Unable to find information for specified path" << endl;
            continue;
        }

        if (S_ISDIR(ip.st_mode))
        {
            if (canCopy(src, dest))
            {
                if (src == dest)
                {
                    cout << endl
                         << "Cannot Copy Parent Directory to Child Directory" << endl;
                    return;
                }

                if (findParent(src) == dest)
                {
                    createDirectoryReplica(src, dest);
                }
                else
                {
                    copyDirectory(src, dest);
                }
            }
        }
        else
        {
            if (findParent(src) == dest)
            {
                createFileReplica(src, dest);
            }
            else
            {
                copyFile(src, dest);
            }
        }
    }
}

//----------------------------------
//---------GET NEW REPLICA----------
//-----------FILE NAME--------------
//----------------------------------
string getFileReplicaName(string src)
{
    string f = getFileName(src);
    int i = f.find_last_of(".");
    string fileExt = f.substr(i);
    string fileName = f.substr(0, i);

    src = findParent(src);
    DIR *dir;
    struct dirent *x;
    string s;
    unordered_map<string, int> umap;

    if ((dir = opendir(src.c_str())) != NULL)
    {
        while ((x = readdir(dir)) != NULL)
        {
            s = x->d_name;
            if (s == "." || s == "..")
                continue;
            umap[s] = 1;
        }

        string toFind = fileName + " (1)" + fileExt;
        int x = 2;
        for (auto it : umap)
        {
            if (umap[toFind] != 1)
            {
                return toFind;
            }
            else
            {
                toFind = fileName + " (" + to_string(x) + ")" + fileExt;
                x++;
            }
        }
        return toFind;
    }
    return "newFile";
}

//----------------------------------
//---------GET NEW REPLICA----------
//---------DIRECTORY NAME-----------
//----------------------------------
string getDirectoryReplicaName(string src)
{
    string fileName = getFileName(src);
    src = findParent(src);
    DIR *dir;
    struct dirent *x;
    string s;
    bool isD;
    unordered_map<string, int> umap;

    if ((dir = opendir(src.c_str())) != NULL)
    {
        while ((x = readdir(dir)) != NULL)
        {
            s = x->d_name;
            if (s == "." || s == "..")
                continue;
            umap[s] = 1;
        }

        string toFind = fileName + " (1)";
        int x = 2;

        for (auto it : umap)
        {
            if (umap[toFind] != 1)
            {
                return toFind;
            }
            else
            {
                toFind = fileName + " (" + to_string(x) + ")";
                x++;
            }
        }
        return toFind;
    }
    return "newDir";
}

//----------------------------------
//---------CREATE REPLICA-----------
//----------OF DIRECTORY------------
//----------------------------------
void createDirectoryReplica(string src, string dest)
{

    string dirNewName = getDirectoryReplicaName(src);
    mode_t perm = getPerm(src);
    createDir(dirNewName, dest, perm);

    dest = dest + "/" + dirNewName;

    DIR *dir;
    struct dirent *x;
    string s;
    bool isD;

    if ((dir = opendir(src.c_str())) != NULL)
    {
        while ((x = readdir(dir)) != NULL)
        {
            s = x->d_name;
            if (s == "." || s == "..")
                continue;

            string srcPath = src + "/" + s;

            if (isDir(srcPath))
            {
                copyDirectory(srcPath, dest);
            }
            else
            {
                copyFile(srcPath, dest);
            }
        }
        closedir(dir);
    }
}


//----------------------------------
//-----------COPY FILE--------------
//--------CREATE REPLICA IF---------
//----FILE ALREADY EXIST IN DEST----
//----------------------------------
void createFileReplica(string sourceFile, string destFile)
{
    int fd_src, fd_dest;
    mode_t perm = getPerm(sourceFile);
    string fileName = getFileName(sourceFile);
    char ch;
    bool isReplica = false;

    string newFileName;
    int ind = fileName.find_last_of(".");

    if (ind == string::npos)
    {
        newFileName = getDirectoryReplicaName(sourceFile);
    }
    else
    {
        newFileName = getFileReplicaName(sourceFile);
    }
    cout << endl
         << "newfilename: " << newFileName << endl;

    if (destFile == "/")
    {
        destFile = destFile + newFileName;
    }
    else
    {
        destFile = destFile + "/" + newFileName;
    }

    if ((fd_src = open(sourceFile.c_str(), O_RDONLY)) == -1)
    {
        cout << endl
             << "Error Opening File" << endl;
        return;
    }
    if ((fd_dest = open(destFile.c_str(), O_RDONLY)) != -1)
    {
        delete_file(destFile);
    }

    fd_dest = open(destFile.c_str(), O_CREAT | O_WRONLY, perm);
    cout << endl
         << "File Copied Successfully" << endl;

    while (read(fd_src, &ch, 1))
        write(fd_dest, &ch, 1);

    close(fd_src);
    close(fd_dest);
    return;
}

//----------------------------------
//-----------COPY FILE--------------
//--------FUNCTION IF FILE----------
//-----DOES NOT EXIST IN DEST-------
//----------------------------------
void copyFile(string sourceFile, string destFile)
{
    int fd_src, fd_dest;
    mode_t perm = getPerm(sourceFile);
    string fileName = getFileName(sourceFile);
    char ch;

    if (destFile == "/")
    {
        destFile = destFile + fileName;
    }
    else
    {
        destFile = destFile + "/" + fileName;
    }

    if ((fd_src = open(sourceFile.c_str(), O_RDONLY)) == -1)
    {
        cout << endl
             << "Error Opening File" << endl;
        return;
    }
    if ((fd_dest = open(destFile.c_str(), O_RDONLY)) != -1)
    {
        delete_file(destFile);
    }

    fd_dest = open(destFile.c_str(), O_CREAT | O_WRONLY, perm);
    cout << endl
         << "File Copied Successfully" << endl;

    while (read(fd_src, &ch, 1))
        write(fd_dest, &ch, 1);

    close(fd_src);
    close(fd_dest);
    return;
}

//----------------------------------
//--------COPY DIRECTORY------------
//-----------FUNCTION---------------
//----------------------------------
void copyDirectory(string src, string dest)
{
    string dirName = getFileName(src);
    string s;
    string tempPath;
    mode_t perm = getPerm(src);
    createDir(dirName, dest, perm);

    DIR *directory = opendir(src.c_str());

    if (!directory)
    {
        cout << "Path does not exist" << endl;
        return;
    }

    struct dirent *x;
    while ((x = readdir(directory)) != NULL)
    {
        s = x->d_name;

        if (src == "/")
        {
            tempPath = src + s;
        }
        else
        {
            tempPath = src + "/" + s;
        }
        if (s == "." || s == "..")
            continue;

        struct stat ip;
        if (stat((tempPath).c_str(), &ip) != 0)
        {
            cout << "File/Directory Not Found" << endl;
        }

        if (S_ISDIR(ip.st_mode))
        {
            copyDirectory(tempPath, dest + "/" + dirName);
        }
        else
        {
            copyFile(tempPath, dest + "/" + dirName);
        }
    }
}

//----------------------------------
//------------CREATE----------------
//-----------DIRECTORY--------------
//----------------------------------
void createDir(string dirToCreate, string path, mode_t perm)
{
    DIR *d = opendir(path.c_str());

    if (d == NULL)
    {
        cout << endl
             << "Invalid Path" << endl;
        return;
    }

    // If read permission is not present for destination
    if (errno == EACCES)
    {
        cout << endl
             << "No Read Permission for file/directory" << strerror(errno) << endl;
        return;
    }

    if (path == "/")
        path = path + dirToCreate;
    else
        path = path + "/" + dirToCreate;
    if (mkdir(path.c_str(), perm) == -1)
    {
        cerr << endl
             << "Error in Creating Directory: " << strerror(errno) << endl;
    }
    else
    {
        cout << endl
             << "Directory Created Successfully" << endl;
    }
}

//----------------------------------
//------------CREATE----------------
//-------------FILE-----------------
//----------------------------------
void createFile(string fileToCreate, string destDir)
{
    string path = destDir;
    string fileName = getFileName(fileToCreate);
    DIR *d = opendir(path.c_str());

    if (d == NULL)
    {
        cout << endl
             << "Invalid Path" << endl;
        return;
    }

    // If read permission is not present for destination
    if (errno == EACCES)
    {
        cout << endl
             << "No Read Permission for file/directory" << strerror(errno) << endl;
        return;
    }

    if (path == "/")
        path = path + fileName;
    else
        path = path + "/" + fileName;

    if (open(path.c_str(), O_RDONLY) != -1)
    {
        cout << endl
             << "Error in Creating File: File Already Exists" << endl;
    }
    else
    {
        if (creat(path.c_str(), DEFAULT_FILE_PERMISSION) == -1)
        {
            cout << endl
                 << "Can't Create File" << endl;
        }
        else
        {
            cout << endl
                 << "File Created Successfully" << endl;
        }
    }
}

//----------------------------------
//------------RENAME----------------
//-----------FUNCTION---------------
//----------------------------------
void rname(string oldFileName, string newFileName)
{
    oldFileName = parsePath(oldFileName);
    newFileName = parsePath(newFileName);

    if ((open(newFileName.c_str(), O_RDONLY)) != -1)
    {
        cout << endl
             << "File/Directory with name " << getFileName(newFileName) << " already exists. Try with different name" << endl;
        return;
    }

    int stat = rename(oldFileName.c_str(), newFileName.c_str());
    if (stat != 0)
        cout << endl
             << "Source File Does not Exist" << endl;
    else
        cout << endl
             << "Renamed successfully" << endl;
}

//----------------------------------
//----------DELETE FILE-------------
//-----------FUNCTION---------------
//----------------------------------
void delete_file(string fname)
{
    fname = parsePath(fname);

    if (unlink(fname.c_str()) == -1)
    {
        cout << "Can't Delete File" << endl;
        return;
    }
    cout << endl
         << "File Deleted Successfully" << endl;
}

//----------------------------------
//----------DELETE SINGLE-----------
//-----------DIRECTORY--------------
//----------------------------------
void deleteSingleDirectory(string dirName)
{
    if (rmdir(dirName.c_str()) == -1)
    {
        cerr << "Error in deleting directory" << dirName << " " << strerror(errno) << endl;
    }
    else
    {
        cout << endl
             << "Directory Removed" << endl;
    }
}

//----------------------------------
//----------DELETE ENTIRE-----------
//-----------DIRECTORY--------------
//----------------------------------
void delete_entire_dir(string dirName)
{
    DIR *dir;
    struct dirent *x;
    string s, tempPath;
    bool isD;

    if ((dir = opendir(dirName.c_str())) != NULL)
    {
        while ((x = readdir(dir)) != NULL)
        {
            s = x->d_name;
            if (s == "." || s == "..")
                continue;

            if (dirName == "/")
            {
                tempPath = dirName + s;
            }
            else
            {
                tempPath = dirName + "/" + s;
            }
            isD = isDir(tempPath);

            if (isD)
            {
                delete_entire_dir(tempPath);
            }
            else
            {
                delete_file(tempPath);
            }
        }
        deleteSingleDirectory(dirName);
    }
}

//----------------------------------
//----------GET FILENAME------------
//-----------FROM PATH--------------
//----------------------------------
string getFileName(string path)
{
    int n = path.size();
    string fname = "";
    for (int i = n - 1; i >= 0; i--)
    {
        if (path[i] == '/')
        {
            fname = path.substr(i + 1);
            break;
        }
    }
    return fname;
}

//----------------------------------
//----------GET ABSOLUTE------------
//-------------PATH-----------------
//----------------------------------
string parsePath(string path)
{
    stack<string> stk;

    int n = path.size();
    string tempPath = "";
    tempPath += path[0];

    for (int i = 1; i < n; i++)
    {
        if (path[i] == '/')
        {
            tempPath = path[i - 1] == '/' ? tempPath : tempPath + path[i];
        }
        else
        {
            tempPath += path[i];
        }
    }
    path = tempPath;

    if (path[0] == '~')
    {
        const char *homePath;
        homePath = getenv("HOME");

        stringstream ss(homePath);
        string res;
        while (getline(ss, res, '/'))
        {
            if (res != "")
                stk.push(res);
        }
        if (path.size() >= 2)
            path = path.substr(2);
        else
            path = "";
    }

    else if (path[0] != '/')
    {
        stringstream ss(currPath);
        string res;

        while (getline(ss, res, '/'))
        {
            if (res != "")
                stk.push(res);
        }
    }

    stringstream ss(path);
    string res = "";
    while (getline(ss, res, '/'))
    {
        if (res != "" && res != ".")
        {
            if (res == "..")
            {
                if (!stk.empty())
                {
                    stk.pop();
                }
            }
            else
                stk.push(res);
        }
    }
    if (stk.size() == 0)
    {
        return "/";
    }
    res = "";
    while (!stk.empty())
    {
        res = "/" + stk.top() + res;
        stk.pop();
    }
    return res;
}

//----------------------------------
//----------CHECK IF PATH-----------
//-----------IS DIRECTORY-----------
//----------------------------------
bool isDir(string path)
{
    struct stat ip;
    stat(path.c_str(), &ip);
    return S_ISDIR(ip.st_mode) ? true : false;
}

mode_t getPerm(string src)
{
    struct stat inode;
    stat(src.c_str(), &inode);
    mode_t p = 0;

    p = p | ((inode.st_mode & S_IRUSR) ? 0400 : 0);
    p = p | ((inode.st_mode & S_IWUSR) ? 0200 : 0);
    p = p | ((inode.st_mode & S_IXUSR) ? 0100 : 0);
    p = p | ((inode.st_mode & S_IRGRP) ? 0040 : 0);
    p = p | ((inode.st_mode & S_IWGRP) ? 0020 : 0);
    p = p | ((inode.st_mode & S_IXGRP) ? 0010 : 0);
    p = p | ((inode.st_mode & S_IROTH) ? 0004 : 0);
    p = p | ((inode.st_mode & S_IWOTH) ? 0002 : 0);
    p = p | ((inode.st_mode & S_IXOTH) ? 0001 : 0);

    return p;
}