#include "headerFiles.h"
#include "getchNonCanonical.h"
#include "moveCursor.h"
#include "normalMode.h"
#include "commandMenuDisplay.h"
#include "commandModeFunctions.h"
#include "listDir.h"

int main()
{
    currPath = getenv("HOME");
    backwardSTK.push(currPath);
    mode=NORMAL_MODE;
    enableRawMode();
    normalMode();
    disableRawMode();
    return 0;
}